package com.tupinicraft;

import java.io.InputStream;
import java.nio.file.Path;
import java.util.*;
import java.util.zip.ZipFile;
import org.objectweb.asm.*;

/** Inspects the real compiled render pipeline; no OpenGL mocks or client bootstrap. */
public final class TigrinhoRenderSelfTest {
    private static final String SCREEN="net/minecraft/client/gui/screens/Screen";
    private static final String TIGRINHO="com/tupinicraft/client/tigrinho/TigrinhoScreen";
    private static final String RENDER="(Lnet/minecraft/client/gui/GuiGraphics;IIF)V";
    private static Map<String,List<String>> calls(byte[] bytes) {
        Map<String,List<String>> methods=new HashMap<>();
        new ClassReader(bytes).accept(new ClassVisitor(Opcodes.ASM9) {
            @Override public MethodVisitor visitMethod(int access,String name,String descriptor,String signature,String[] exceptions) {
                List<String> list=new ArrayList<>(); methods.put(name+descriptor,list);
                return new MethodVisitor(Opcodes.ASM9) {
                    @Override public void visitMethodInsn(int opcode,String owner,String name,String desc,boolean itf) {
                        list.add(owner+"."+name+desc);
                    }
                };
            }
        },ClassReader.SKIP_DEBUG|ClassReader.SKIP_FRAMES);
        return methods;
    }
    private static byte[] resource(String name) throws Exception {
        try(InputStream in=TigrinhoRenderSelfTest.class.getClassLoader().getResourceAsStream(name+".class")) {
            if(in==null) throw new AssertionError("Missing class: "+name);
            return in.readAllBytes();
        }
    }
    private static void check(boolean ok,String message) { if(!ok) throw new AssertionError(message); }
    public static void main(String[] args) throws Exception {
        byte[] target;
        if(args.length==0) target=resource(TIGRINHO);
        else try(ZipFile zip=new ZipFile(Path.of(args[0]).toFile())) {
            target=zip.getInputStream(zip.getEntry(TIGRINHO+".class")).readAllBytes();
        }
        var vanilla=calls(resource(SCREEN));
        var screenRender=vanilla.get("render"+RENDER);
        int background=-1,widgets=-1;
        for(int i=0;i<screenRender.size();i++) {
            String call=screenRender.get(i);
            if(call.contains(".renderBackground"+RENDER)) background=i;
            if(call.contains("/Renderable.render"+RENDER)) widgets=i;
        }
        check(background>=0 && widgets>background,"Engine must draw background before widgets");
        var custom=calls(target);
        var customBackground=custom.get("renderBackground"+RENDER);
        check(customBackground!=null,"Tigrinho must override renderBackground; inherited blur smears cabinet");
        check(customBackground.stream().noneMatch(c->c.contains(".renderBackground")||c.contains(".renderBlurredBackground")||c.contains(".processBlurEffect")),"Tigrinho background must not call vanilla blur");
        check(customBackground.stream().anyMatch(c->c.startsWith(TIGRINHO+".renderReels")),"Reels belong to background pass");
        check(customBackground.stream().anyMatch(c->c.startsWith(TIGRINHO+".renderTable")),"Prize table belongs to background pass");
        check(custom.get("render"+RENDER).stream().filter(c->c.equals(SCREEN+".render"+RENDER)).count()==1,"Preserve one superclass render for widgets");
        System.out.println("Tigrinho render: 6 pipeline checks passed (compiled classes; not a visual Minecraft test)");
    }
}
