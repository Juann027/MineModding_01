# Alterações sobre a versão 0.5.4 anexada

Nenhum arquivo original removido. Somente TigrinhoScreen foi alterada entre as classes de produção; UI Cívica e demais recursos preservados.

## Modificados

- `LEIA-ME.txt`
- `MineModding_01-main/README.md`
- `MineModding_01-main/build.gradle`
- `MineModding_01-main/docs/UI_CIVICA.md`
- `MineModding_01-main/gradle.properties`
- `MineModding_01-main/src/main/java/com/tupinicraft/client/tigrinho/TigrinhoScreen.java`

## Adicionados

- `MineModding_01-main/dist/tupinicraft-0.5.4-ui-tigrinho-fix.jar`
- `MineModding_01-main/docs/ARQUIVOS_BLUR_FIX.md`
- `MineModding_01-main/docs/TIGRINHO_BLUR_FIX.md`
- `MineModding_01-main/docs/validacao-0.5.4-tigrinho/build.txt`
- `MineModding_01-main/docs/validacao-0.5.4-tigrinho/controle-negativo-jar-antigo.txt`
- `MineModding_01-main/docs/validacao-0.5.4-tigrinho/server-first.txt`
- `MineModding_01-main/docs/validacao-0.5.4-tigrinho/server-second.txt`
- `MineModding_01-main/docs/validacao-0.5.4-tigrinho/server-smoke.txt`
- `MineModding_01-main/src/test/java/com/tupinicraft/TigrinhoRenderSelfTest.java`
