# Correção do fundo embaçado — 0.5.4-ui-tigrinho-fix

## Defeito observado
O gabinete, os símbolos e os textos do Tigrinho eram desenhados antes de `super.render()`. No Minecraft 1.21.1, `Screen.render()` chama `renderBackground()`, que por padrão aplica desfoque ao quadro inteiro, e só depois desenha os widgets. Assim, o gabinete ficava embaçado enquanto os botões permaneciam nítidos, como na imagem enviada.

## Correção
`TigrinhoScreen` agora sobrescreve `renderBackground()` com o desenho do seu próprio painel. `render()` mantém a camada escura externa e a transformação de escala, depois delega uma única vez a `Screen.render()`. A chamada despacha para o fundo do Tigrinho, sem desfoque, antes dos botões. Nenhuma opção global de vídeo foi alterada, e a UI Cívica, as recompensas e o código de servidor foram preservados.

A correção anterior de `Session(p, pos, now)` já estava no ZIP recebido. Ela resolvia compilação, não o desfoque.

## Verificação
O teste `TigrinhoRenderSelfTest` inspeciona as classes compiladas reais do Minecraft e do mod: verifica a ordem fundo/widgets, a substituição de `renderBackground`, a ausência de chamadas ao desfoque nesse método e a renderização dos rolos/tabela nessa etapa. Ele não usa mocks de OpenGL e não é um teste visual do jogo.

Resultados executados:
- Build completo: aprovado.
- Testes do projeto: 136 aprovados; regressões: 27 aprovadas.
- UI Cívica: 2.491 verificações aprovadas; Tigrinho: 2.169 aprovadas.
- Renderização: seis verificações das classes compiladas aprovadas.
- Controle negativo: o mesmo teste falhou no JAR 0.5.3 antigo, com a mensagem `Tigrinho must override renderBackground; inherited blur smears cabinet`. Essa falha é esperada e demonstra que o teste detecta o código defeituoso; não é falha do build novo.

Os logs estão em `docs/validacao-0.5.4-tigrinho/`. A aparência final no cliente Minecraft continua necessitando conferência visual; não foi declarada como testada a partir de testes de lógica ou bytecode.

## Instalação
Use apenas `dist/tupinicraft-0.5.4-ui-tigrinho-fix.jar` em `mods`, substituindo o JAR anterior do TupiniCraft. Não instale dois JARs do mesmo mod. Use o mesmo build no cliente e no servidor e mantenha as dependências existentes. Minecraft 1.21.1 / NeoForge 21.1.265 / Java 21. Protocolo 4 preservado.

## Conferência visual
Abra o item ou a máquina com o desfoque dos menus habilitado nas opções. Mascote, títulos, saldo, rolos e tabela devem ficar nítidos, assim como os botões. Teste também escalas de GUI diferentes e redimensionamento. Não é necessário desativar o desfoque global.

Servidor dedicado: teste de fumaça aprovado nas duas inicializações; máquina colocada e confirmada após reinício (`TIGRINHO_MACHINE_PERSISTED`). Esse teste não valida a aparência da interface.
